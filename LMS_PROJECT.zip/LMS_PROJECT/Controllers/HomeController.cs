﻿using System.Web.Mvc;

namespace LMS_PROJECT.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            return View();
        }

        public ActionResult Contact()
        {
            return View();
        }

        public ActionResult Courses()
        {
            return View();
        }

        public ActionResult Reviews()
        {
            return View();
        }
        public ActionResult Blog()
        {
            return View();
        }
        public ActionResult Teacher()
        {
            return View();
        }
        public ActionResult Login()
        {
            return View();
        }
        public ActionResult SignUp()
        {
            return View();
        }
    }
}